# Presentation Notes — SET-CDP AdShield Pro

## Problem

Modern websites often load ads, tracking scripts, third-party iframes, analytics beacons, and sponsored elements that affect:

- User privacy
- Page performance
- Browsing experience
- Data consumption
- Security exposure

## Solution

SET-CDP AdShield Pro uses two layers:

1. Network Blocking:
   - Uses Chrome Declarative Net Request rules.
   - Blocks known ad and tracker domains before they load.

2. Cosmetic Cleaning:
   - Injects CSS and scans DOM elements.
   - Hides visible ad containers and sponsored blocks.

## Why Manifest V3?

Manifest V3 is the current Chrome extension architecture. It improves performance and security by using declarative rules instead of continuous request interception.

## Limitations

Some platforms, especially YouTube, update ad delivery frequently. The extension improves blocking but cannot guarantee perfect blocking on every site forever.

## Future Work

- Add custom blocklist import
- Add allowlist per site
- Add blocked request statistics
- Add community filter syntax parser
- Add dashboard integration
