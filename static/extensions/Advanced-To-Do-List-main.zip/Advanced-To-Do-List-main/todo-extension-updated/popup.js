// DOM Elements
const taskInput = document.getElementById("taskInput");
const dueDateInput = document.getElementById("dueDateInput");
const categoryInput = document.getElementById("categoryInput");
const addBtn = document.getElementById("addBtn");
const taskList = document.getElementById("taskList");
const clearAllBtn = document.getElementById("clearAllBtn");
const exportBtn = document.getElementById("exportBtn");
const importBtn = document.getElementById("importBtn");
const themeToggle = document.getElementById("themeToggle");

// State
let currentFilter = 'all';

// Initialize the app
function init() {
  loadThemePreference();
  loadTasks();
  setupEventListeners();
}

// Load user's theme preference
function loadThemePreference() {
  chrome.storage.sync.get(['darkMode'], (result) => {
    if (result.darkMode) {
      document.body.classList.add('dark-mode');
    }
  });
}

// Load tasks from storage
function loadTasks() {
  chrome.storage.sync.get("tasks", (data) => {
    const tasks = data.tasks || [];
    renderFilteredTasks(tasks);
    updateStats(tasks);
  });
}

// Set up event listeners
function setupEventListeners() {
  // Add task
  addBtn.addEventListener("click", addTask);
  
  // Smart input detection
  taskInput.addEventListener("blur", detectSmartInput);
  
  // Theme toggle
  themeToggle.addEventListener('click', toggleTheme);
  
  // Clear all tasks
  clearAllBtn.addEventListener('click', clearAllTasks);
  
  // Export/Import
  exportBtn.addEventListener('click', exportTasks);
  importBtn.addEventListener('click', importTasks);
  
  // Filters
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.filter;
      chrome.storage.sync.get("tasks", (data) => {
        renderFilteredTasks(data.tasks || []);
      });
    });
  });
}

// Add a new task
function addTask() {
  const taskText = taskInput.value.trim();
  const dueDate = dueDateInput.value;
  const category = categoryInput.value;
  
  if (!taskText) return;

  chrome.storage.sync.get("tasks", (data) => {
    const tasks = data.tasks || [];
    const newTask = { 
      text: taskText, 
      done: false, 
      due: dueDate,
      category: category 
    };
    
    tasks.push(newTask);
    saveTasks(tasks);
    
    // Clear inputs
    taskInput.value = "";
    dueDateInput.value = "";
    categoryInput.value = "";
  });
}

// Detect smart input (natural language dates)
function detectSmartInput() {
  const text = taskInput.value;
  const result = chrono.parse(text);
  
  if (result.length > 0 && result[0].start) {
    const date = result[0].start.date();
    dueDateInput.value = date.toISOString().slice(0, 16);
    taskInput.value = text.replace(result[0].text, "").trim();
  }
}

// Toggle dark/light theme
function toggleTheme() {
  document.body.classList.toggle('dark-mode');
  const isDarkMode = document.body.classList.contains('dark-mode');
  chrome.storage.sync.set({ darkMode: isDarkMode });
}

// Clear all tasks
function clearAllTasks() {
  if (confirm('Are you sure you want to delete all tasks?')) {
    chrome.storage.sync.set({ tasks: [] }, () => {
      renderTasks([]);
      updateStats([]);
    });
  }
}

// Export tasks to JSON file
function exportTasks() {
  chrome.storage.sync.get("tasks", (data) => {
    const tasks = data.tasks || [];
    const blob = new Blob([JSON.stringify(tasks, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'tasks-export.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  });
}

// Import tasks from JSON file
function importTasks() {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.json';
  
  input.onchange = e => {
    const file = e.target.files[0];
    const reader = new FileReader();
    
    reader.onload = event => {
      try {
        const tasks = JSON.parse(event.target.result);
        if (Array.isArray(tasks)) {
          saveTasks(tasks);
        } else {
          alert('Invalid file format. Expected an array of tasks.');
        }
      } catch (error) {
        alert('Error parsing JSON file: ' + error.message);
      }
    };
    
    reader.readAsText(file);
  };
  
  input.click();
}

// Save tasks to storage
function saveTasks(tasks) {
  chrome.storage.sync.set({ tasks }, () => {
    // Clear all existing alarms
    chrome.alarms.getAll((alarms) => {
      alarms.forEach(alarm => chrome.alarms.clear(alarm.name));
    });
    
    // Schedule new alarms for pending tasks with due dates
    tasks.forEach(task => {
      if (!task.done && task.due) {
        scheduleNotification(task);
      }
    });
    
    renderFilteredTasks(tasks);
    updateStats(tasks);
  });
}

// Schedule notification for a task
function scheduleNotification(task) {
  if (!task.due) return;

  const dueDate = new Date(task.due);
  const reminderTime = new Date(dueDate.getTime() - 30 * 60000); // 30 minutes before

  chrome.alarms.create(JSON.stringify(task), {
    when: reminderTime.getTime()
  });
}

// Render tasks based on current filter
function renderFilteredTasks(tasks) {
  const now = new Date();
  const filteredTasks = tasks.filter(task => {
    if (currentFilter === 'all') return true;
    if (currentFilter === 'completed') return task.done;
    if (currentFilter === 'pending') return !task.done;
    if (currentFilter === 'overdue') return !task.done && task.due && new Date(task.due) < now;
    return true;
  });
  renderTasks(filteredTasks);
}

// Render tasks to the DOM
function renderTasks(tasks = []) {
  taskList.innerHTML = "";
  const now = new Date();

  tasks.forEach((task, index) => {
    const li = document.createElement("li");
    li.draggable = true;
    li.dataset.index = index;
    
    // Drag and drop functionality
    li.addEventListener('dragstart', (e) => {
      e.dataTransfer.setData('text/plain', index);
    });

    li.addEventListener('dragover', (e) => {
      e.preventDefault();
      li.classList.add('drag-over');
    });

    li.addEventListener('dragleave', () => {
      li.classList.remove('drag-over');
    });

    li.addEventListener('drop', (e) => {
      e.preventDefault();
      li.classList.remove('drag-over');
      
      const fromIndex = e.dataTransfer.getData('text/plain');
      const toIndex = index;
      
      if (fromIndex !== toIndex) {
        chrome.storage.sync.get("tasks", (data) => {
          const allTasks = data.tasks || [];
          const [movedTask] = allTasks.splice(fromIndex, 1);
          allTasks.splice(toIndex, 0, movedTask);
          saveTasks(allTasks);
        });
      }
    });

    // Task text with category
    const taskContent = document.createElement("div");
    taskContent.className = "task-content";
    
    if (task.category) {
      const categorySpan = document.createElement("span");
      categorySpan.className = `task-category category-${task.category}`;
      categorySpan.textContent = task.category;
      taskContent.appendChild(categorySpan);
    }

    const taskText = document.createElement("span");
    taskText.className = "task-text";
    taskText.textContent = task.text;
    
    if (task.due) {
      const dueDate = new Date(task.due);
      taskText.textContent += ` (Due: ${dueDate.toLocaleString()})`;
    }
    
    if (task.done) taskText.classList.add("done");
    taskContent.appendChild(taskText);
    li.appendChild(taskContent);

    // Color coding based on due date
    if (task.due) {
      const dueDate = new Date(task.due);
      const timeDiff = dueDate - now;
      if (timeDiff < 0) {
        li.classList.add("red");
      } else if (timeDiff < 86400000) { // Less than 1 day
        li.classList.add("yellow");
      } else {
        li.classList.add("green");
      }
    }

    // Toggle task completion
    taskText.addEventListener("click", () => {
      chrome.storage.sync.get("tasks", (data) => {
        const allTasks = data.tasks || [];
        allTasks[index].done = !allTasks[index].done;
        saveTasks(allTasks);
      });
    });

    // Edit button
    const editBtn = document.createElement("button");
    editBtn.textContent = "✏️";
    editBtn.className = "edit-btn";
    editBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      chrome.storage.sync.get("tasks", (data) => {
        const allTasks = data.tasks || [];
        const taskToEdit = allTasks[index];
        
        const newText = prompt("Edit task:", taskToEdit.text);
        if (newText !== null) {
          taskToEdit.text = newText;
          
          const currentDue = taskToEdit.due ? new Date(taskToEdit.due).toISOString().slice(0, 16) : '';
          const newDue = prompt("Edit due date (yyyy-mm-ddThh:mm):", currentDue);
          if (newDue !== null) taskToEdit.due = newDue;
          
          const newCategory = prompt("Edit category (personal, work, study, other):", taskToEdit.category || '');
          if (newCategory !== null) taskToEdit.category = newCategory;
          
          saveTasks(allTasks);
        }
      });
    });

    // Delete button
    const deleteBtn = document.createElement("button");
    deleteBtn.textContent = "❌";
    deleteBtn.className = "delete-btn";
    deleteBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (confirm("Are you sure you want to delete this task?")) {
        chrome.storage.sync.get("tasks", (data) => {
          const allTasks = data.tasks || [];
          allTasks.splice(index, 1);
          saveTasks(allTasks);
        });
      }
    });

    // Append buttons
    const taskActions = document.createElement("div");
    taskActions.className = "task-actions";
    taskActions.appendChild(editBtn);
    taskActions.appendChild(deleteBtn);
    li.appendChild(taskActions);

    taskList.appendChild(li);
  });
}

// Update statistics
function updateStats(tasks) {
  const now = new Date();
  const stats = {
    total: tasks.length,
    completed: 0,
    pending: 0,
    overdue: 0
  };

  tasks.forEach(task => {
    if (task.done) {
      stats.completed++;
    } else if (task.due && new Date(task.due) < now) {
      stats.overdue++;
    } else {
      stats.pending++;
    }
  });

  document.getElementById("totalCount").textContent = stats.total;
  document.getElementById("completedCount").textContent = stats.completed;
  document.getElementById("pendingCount").textContent = stats.pending;
  document.getElementById("overdueCount").textContent = stats.overdue;
}

// Initialize the app
init();