
chrome.runtime.onInstalled.addListener(async () => {
  const data = await chrome.storage.local.get(["enabled", "cosmetic", "privacy"]);
  if (data.enabled === undefined) await chrome.storage.local.set({ enabled: true });
  if (data.cosmetic === undefined) await chrome.storage.local.set({ cosmetic: true });
  if (data.privacy === undefined) await chrome.storage.local.set({ privacy: true });
  await syncRulesets();
});

chrome.runtime.onStartup.addListener(syncRulesets);

async function syncRulesets() {
  const { enabled = true, privacy = true } = await chrome.storage.local.get(["enabled", "privacy"]);
  const enableRuleSetIds = [];
  const disableRuleSetIds = [];

  if (enabled) enableRuleSetIds.push("ad_rules");
  else disableRuleSetIds.push("ad_rules");

  if (enabled && privacy) enableRuleSetIds.push("privacy_rules");
  else disableRuleSetIds.push("privacy_rules");

  await chrome.declarativeNetRequest.updateEnabledRulesets({
    enableRulesetIds: enableRuleSetIds,
    disableRulesetIds: disableRuleSetIds
  });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "SYNC_RULESETS") {
    syncRulesets().then(() => sendResponse({ ok: true }));
    return true;
  }
});
