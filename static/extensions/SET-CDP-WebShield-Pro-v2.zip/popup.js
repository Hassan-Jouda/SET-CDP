const $ = (id) => document.getElementById(id);

const suspiciousWords = [
  'login','verify','account','secure','update','confirm','password','signin','banking','wallet','crypto',
  'free','gift','bonus','prize','urgent','limited','support','security','paypal','facebook','whatsapp','telegram'
];
const shorteners = ['bit.ly','tinyurl.com','t.co','goo.gl','ow.ly','is.gd','cutt.ly','rebrand.ly','buff.ly','shorturl.at','rb.gy','s.id'];
const popularBrands = ['google','facebook','meta','paypal','microsoft','apple','netflix','instagram','whatsapp','telegram','amazon','binance','bank'];
const riskyTlds = ['zip','mov','click','country','kim','work','top','xyz','tk','ml','ga','cf','gq','support','quest'];

function normalizeUrl(raw) {
  raw = (raw || '').trim();
  if (!raw) return null;
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(raw)) raw = 'https://' + raw;
  try { return new URL(raw); } catch { return null; }
}

function isIp(host) {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(host) || /^\[[0-9a-f:]+\]$/i.test(host);
}
function entropyEstimate(pwd) {
  let pool = 0;
  if (/[a-z]/.test(pwd)) pool += 26;
  if (/[A-Z]/.test(pwd)) pool += 26;
  if (/\d/.test(pwd)) pool += 10;
  if (/[^a-zA-Z0-9]/.test(pwd)) pool += 33;
  return Math.round(pwd.length * Math.log2(Math.max(pool, 1)));
}
function escapeHtml(s) { return String(s).replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }

function analyzeUrl(rawUrl) {
  const url = normalizeUrl(rawUrl);
  if (!url) return { score: 75, level: 'bad', title: 'رابط غير صالح', host: rawUrl, findings: [{sev:'high', text:'تعذر قراءة الرابط. تأكد من كتابته بشكل صحيح.'}] };

  const host = url.hostname.toLowerCase();
  const full = url.href.toLowerCase();
  const labels = host.split('.');
  const tld = labels[labels.length - 1] || '';
  const findings = [];
  let score = 0;

  const add = (sev, points, text) => { findings.push({sev, text}); score += points; };

  if (url.protocol !== 'https:') add('high', 25, 'الرابط لا يستخدم HTTPS، وهذا خطر خصوصاً في صفحات تسجيل الدخول والدفع.');
  if (isIp(host)) add('high', 25, 'الرابط يستخدم عنوان IP بدلاً من اسم نطاق واضح.');
  if (full.includes('@')) add('high', 22, 'وجود الرمز @ داخل الرابط قد يخفي الوجهة الحقيقية.');
  if (shorteners.includes(host.replace(/^www\./,''))) add('medium', 18, 'الرابط مختصر، وهذا قد يخفي الموقع النهائي.');
  if (host.length > 45) add('medium', 12, 'اسم النطاق طويل جداً وقد يستخدم لخداع المستخدم.');
  if ((host.match(/-/g) || []).length >= 3) add('medium', 10, 'النطاق يحتوي على شرطات كثيرة، وهذا مؤشر شائع في الروابط المزيفة.');
  if (labels.length >= 5) add('medium', 10, 'عدد النطاقات الفرعية كبير وغير معتاد.');
  if (riskyTlds.includes(tld)) add('medium', 10, `امتداد النطاق .${tld} يحتاج حذراً إضافياً.`);
  if (/xn--/.test(host)) add('high', 22, 'النطاق يحتوي على Punycode وقد يشير إلى هجوم تشابه أحرف Homograph.');
  if (/https?:/i.test(url.pathname + url.search)) add('high', 18, 'الرابط يحتوي على رابط آخر داخله، وقد يكون إعادة توجيه مشبوهة.');

  const digitCount = (host.match(/\d/g) || []).length;
  if (digitCount >= 5) add('medium', 8, 'النطاق يحتوي على أرقام كثيرة.');

  const foundWords = suspiciousWords.filter(w => full.includes(w));
  if (foundWords.length >= 3) add('medium', 8, 'الرابط يحتوي على كلمات ضغط أو تسجيل دخول كثيرة: ' + foundWords.slice(0,5).join(', '));

  for (const brand of popularBrands) {
    if (host.includes(brand) && !host.endsWith(brand + '.com') && !host.endsWith(brand + '.org') && !host.endsWith(brand + '.net')) {
      add('medium', 12, `النطاق يذكر علامة معروفة (${brand}) لكنه ليس النطاق الرسمي الواضح.`);
      break;
    }
  }

  if (findings.length === 0) {
    findings.push({sev:'low', text:'لم تظهر مؤشرات خطورة واضحة من الفحص المحلي. استمر بالتأكد من هوية الموقع قبل إدخال بياناتك.'});
  }

  score = Math.min(score, 100);
  let level = 'safe', title = 'منخفض الخطورة';
  if (score >= 70) { level = 'bad'; title = 'مرتفع الخطورة'; }
  else if (score >= 35) { level = 'warn'; title = 'متوسط الخطورة'; }

  return { score, level, title, host: url.href, findings };
}

function renderAnalysis(result) {
  $('scoreCircle').textContent = result.score;
  $('riskTitle').textContent = result.title;
  $('currentUrl').textContent = result.host;
  const bar = $('scoreBar');
  bar.style.width = `${Math.max(result.score, 5)}%`;
  bar.style.background = result.score >= 70 ? '#dc2626' : result.score >= 35 ? '#f97316' : '#16a34a';
  $('scoreCircle').style.borderColor = result.score >= 70 ? '#dc2626' : result.score >= 35 ? '#f97316' : '#16a34a';
  $('urlFindings').innerHTML = result.findings.map(f => `<div class="finding ${f.sev}">${escapeHtml(f.text)}</div>`).join('');
}

async function addHistory(result) {
  const item = { url: result.host, score: result.score, title: result.title, ts: new Date().toLocaleString() };
  const data = await chrome.storage.local.get({ history: [] });
  const history = [item, ...data.history].slice(0, 8);
  await chrome.storage.local.set({ history });
  renderHistory(history);
}
function renderHistory(history) {
  if (!history || history.length === 0) { $('history').innerHTML = '<span class="info">لا يوجد سجل بعد.</span>'; return; }
  $('history').innerHTML = history.map(h => {
    const cls = h.score >= 70 ? 'bad' : h.score >= 35 ? 'warn' : 'safe';
    return `<div class="hist-item"><b class="ltr">${escapeHtml(h.url)}</b><span class="tag ${cls}">${h.score}/100 - ${escapeHtml(h.title)}</span> <span class="muted">${escapeHtml(h.ts)}</span></div>`;
  }).join('');
}

async function scanCurrentTabUrl() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const current = tab?.url || '';
  if (current.startsWith('chrome://') || current.startsWith('edge://') || current.startsWith('about:')) {
    const result = { score: 0, level:'safe', title:'صفحة متصفح داخلية', host: current, findings:[{sev:'low', text:'هذه صفحة داخلية من المتصفح ولا يمكن فحصها كصفحة ويب عادية.'}] };
    renderAnalysis(result); return;
  }
  const result = analyzeUrl(current);
  renderAnalysis(result);
  await addHistory(result);
}

async function scanPage() {
  $('pageFindings').innerHTML = '<span class="info">جاري تحليل الصفحة محلياً...</span>';
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const forms = [...document.forms].map(f => ({
          action: f.action || location.href,
          method: (f.method || 'GET').toUpperCase(),
          passwordFields: f.querySelectorAll('input[type="password"]').length,
          inputs: f.querySelectorAll('input').length,
          hasAutocompleteOff: f.getAttribute('autocomplete') === 'off'
        }));
        const links = [...document.links].slice(0, 250).map(a => a.href).filter(Boolean);
        const externalLinks = links.filter(h => {
          try { return new URL(h).hostname !== location.hostname; } catch { return false; }
        }).length;
        return { forms, totalLinks: links.length, externalLinks, title: document.title, protocol: location.protocol };
      }
    });
    const info = results[0].result;
    const issues = [];
    const add = (sev, text) => issues.push({sev, text});
    if (info.protocol !== 'https:') add('high', 'الصفحة نفسها ليست HTTPS. لا تدخل بيانات حساسة.');
    if (info.forms.length === 0) add('low', 'لا توجد نماذج إدخال في الصفحة الحالية.');
    info.forms.forEach((f, i) => {
      let actionUrl = normalizeUrl(f.action);
      if (f.passwordFields > 0 && info.protocol !== 'https:') add('high', `النموذج رقم ${i+1} يحتوي حقل كلمة مرور على صفحة غير مشفرة.`);
      if (f.method !== 'POST' && f.passwordFields > 0) add('medium', `النموذج رقم ${i+1} يستخدم ${f.method} بدلاً من POST مع حقل كلمة مرور.`);
      if (actionUrl && actionUrl.hostname !== location.hostname) add('medium', `النموذج رقم ${i+1} يرسل البيانات إلى نطاق مختلف: ${actionUrl.hostname}`);
      if (f.passwordFields > 0 && f.hasAutocompleteOff) add('low', `النموذج رقم ${i+1} عطّل autocomplete؛ هذا ليس خطيراً وحده لكنه يستحق الانتباه.`);
    });
    if (info.externalLinks > 20) add('medium', `الصفحة تحتوي على عدد كبير من الروابط الخارجية: ${info.externalLinks}.`);
    if (issues.length === 0) add('low', 'لم تظهر مؤشرات خطورة واضحة في بنية الصفحة الحالية.');
    $('pageFindings').innerHTML = issues.map(f => `<div class="finding ${f.sev}">${escapeHtml(f.text)}</div>`).join('');
  } catch (e) {
    $('pageFindings').innerHTML = '<div class="finding medium">تعذر فحص الصفحة. بعض صفحات المتصفح أو المتاجر تمنع حقن السكربتات لأسباب أمنية.</div>';
  }
}

function secureRandomIndex(max) {
  const arr = new Uint32Array(1);
  crypto.getRandomValues(arr);
  return arr[0] % max;
}
function shuffle(str) {
  const arr = str.split('');
  for (let i = arr.length - 1; i > 0; i--) {
    const j = secureRandomIndex(i + 1);
    [arr[i], arr[j]] = [arr[j], arr[i]];
  }
  return arr.join('');
}
function generatePassword() {
  const sets = [];
  if ($('upper').checked) sets.push('ABCDEFGHIJKLMNOPQRSTUVWXYZ');
  if ($('lower').checked) sets.push('abcdefghijklmnopqrstuvwxyz');
  if ($('numbers').checked) sets.push('0123456789');
  if ($('symbols').checked) sets.push('!@#$%^&*()_+-=[]{};:,.?/|~');
  if (sets.length === 0) { $('pwdStrength').textContent = 'اختر نوعاً واحداً على الأقل.'; return; }
  const len = Number($('pwdLen').value);
  let pwd = sets.map(s => s[secureRandomIndex(s.length)]).join('');
  const all = sets.join('');
  while (pwd.length < len) pwd += all[secureRandomIndex(all.length)];
  pwd = shuffle(pwd).slice(0, len);
  $('passwordOut').value = pwd;
  const bits = entropyEstimate(pwd);
  $('pwdStrength').textContent = `القوة التقديرية: ${bits} bits - ${bits >= 100 ? 'قوية جداً' : bits >= 70 ? 'قوية' : 'متوسطة'}`;
}

document.addEventListener('DOMContentLoaded', async () => {
  $('pwdLen').addEventListener('input', () => $('pwdLenVal').textContent = $('pwdLen').value);
  $('genBtn').addEventListener('click', generatePassword);
  $('copyBtn').addEventListener('click', async () => {
    if (!$('passwordOut').value) return;
    await navigator.clipboard.writeText($('passwordOut').value);
    $('copyBtn').textContent = 'تم النسخ'; $('copyBtn').classList.add('copied');
    setTimeout(() => { $('copyBtn').textContent = 'نسخ'; $('copyBtn').classList.remove('copied'); }, 1200);
  });
  $('manualScanBtn').addEventListener('click', async () => {
    const result = analyzeUrl($('manualUrl').value);
    renderAnalysis(result);
    await addHistory(result);
  });
  $('scanPageBtn').addEventListener('click', scanPage);
  $('clearHistory').addEventListener('click', async () => { await chrome.storage.local.set({ history: [] }); renderHistory([]); });
  const data = await chrome.storage.local.get({ history: [] });
  renderHistory(data.history);
  await scanCurrentTabUrl();
});
