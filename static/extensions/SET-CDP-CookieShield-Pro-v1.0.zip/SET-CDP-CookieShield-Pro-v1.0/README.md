# SET-CDP CookieShield Pro

**SET-CDP CookieShield Pro** is a defensive browser extension for managing and auditing cookies on the current website.

## Main Features

- View cookies for the current website
- Search and filter cookies
- Create, edit, and delete cookies
- Bulk delete session cookies
- Bulk delete cookies without the Secure flag
- Security audit score from 0 to 100
- Detect missing Secure, HttpOnly, and SameSite settings
- Identify long-lived cookies
- Export a privacy-safe JSON audit report without cookie values
- Arabic RTL interface

## Security Notes

This extension is designed for:
- Web developers
- Cybersecurity students
- Security awareness training
- Defensive website testing
- Cookie privacy review

It is **not** designed for stealing, collecting, importing, or transferring cookies from other users or devices.

## How to Install

1. Extract the ZIP file.
2. Open Chrome or Edge.
3. Go to:

```text
chrome://extensions/
```

or:

```text
edge://extensions/
```

4. Enable **Developer mode**.
5. Click **Load unpacked**.
6. Select the extracted folder.

## Suggested Graduation Project Use

This extension can be presented as part of a cyber security platform:

- Cookie Security Auditor
- Privacy Awareness Tool
- Developer Cookie Manager
- Session Security Demonstrator
- Secure Web Development Support Tool

## What the Audit Checks

| Check | Purpose |
|---|---|
| Secure | Ensures cookies are sent only over HTTPS |
| HttpOnly | Reduces JavaScript access in case of XSS |
| SameSite | Helps reduce CSRF risks |
| Expiration | Detects long-lived cookies |
| Third-party-like cookies | Helps privacy review |

## Privacy

The audit report does not include cookie values. It includes only metadata and security flags.
