
const $ = (id) => document.getElementById(id);

document.addEventListener("DOMContentLoaded", init);

async function init() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  try {
    $("site").textContent = new URL(tab.url).hostname;
  } catch {
    $("site").textContent = "صفحة داخلية";
  }

  const data = await chrome.storage.local.get(["enabled", "privacy", "cosmetic", "lastHiddenCount", "lastCleanedHost"]);
  $("enabledToggle").checked = data.enabled !== false;
  $("privacyToggle").checked = data.privacy !== false;
  $("cosmeticToggle").checked = data.cosmetic !== false;
  $("hiddenCount").textContent = data.lastHiddenCount || 0;
  $("rulesCount").textContent = "90+";

  updateUI();

  $("enabledToggle").addEventListener("change", save);
  $("privacyToggle").addEventListener("change", save);
  $("cosmeticToggle").addEventListener("change", save);

  $("reloadBtn").addEventListener("click", async () => {
    await save();
    const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (t && t.id) chrome.tabs.reload(t.id);
    window.close();
  });

  $("resetBtn").addEventListener("click", async () => {
    await chrome.storage.local.set({ enabled: true, privacy: true, cosmetic: true });
    await chrome.runtime.sendMessage({ type: "SYNC_RULESETS" });
    $("enabledToggle").checked = true;
    $("privacyToggle").checked = true;
    $("cosmeticToggle").checked = true;
    updateUI();
  });
}

async function save() {
  await chrome.storage.local.set({
    enabled: $("enabledToggle").checked,
    privacy: $("privacyToggle").checked,
    cosmetic: $("cosmeticToggle").checked
  });
  await chrome.runtime.sendMessage({ type: "SYNC_RULESETS" });
  updateUI();
}

function updateUI() {
  const enabled = $("enabledToggle").checked;
  $("statusBadge").textContent = enabled ? "ON" : "OFF";
  $("statusBadge").classList.toggle("off", !enabled);
  $("mainStatus").textContent = enabled ? "الحماية مفعلة" : "الحماية متوقفة";
  $("mainText").textContent = enabled
    ? "حجب إعلانات + حماية خصوصية + تنظيف بصري."
    : "لن يتم حجب الإعلانات حتى تفعّل الحماية.";
  $("shieldIcon").textContent = enabled ? "✓" : "!";
}
