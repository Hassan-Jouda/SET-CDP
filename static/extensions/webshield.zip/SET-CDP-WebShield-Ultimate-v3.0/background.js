'use strict';

const HEADER_KEY_PREFIX = 'webshield_headers_';
const MAX_HEADER_AGE_MS = 10 * 60 * 1000;

function normalizeHeaders(responseHeaders = []) {
  const headers = {};
  for (const header of responseHeaders) {
    if (!header || !header.name) continue;
    const name = String(header.name).toLowerCase();
    const value = header.value || '';
    if (headers[name]) {
      headers[name] += `, ${value}`;
    } else {
      headers[name] = value;
    }
  }
  return headers;
}

chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    if (details.tabId < 0 || !details.responseHeaders) return;
    if (!/^https?:\/\//i.test(details.url)) return;

    const payload = {
      url: details.url,
      tabId: details.tabId,
      capturedAt: Date.now(),
      headers: normalizeHeaders(details.responseHeaders)
    };

    chrome.storage.local.set({ [`${HEADER_KEY_PREFIX}${details.tabId}`]: payload });
  },
  { urls: ['http://*/*', 'https://*/*'], types: ['main_frame'] },
  ['responseHeaders']
);

chrome.tabs.onRemoved.addListener((tabId) => {
  chrome.storage.local.remove(`${HEADER_KEY_PREFIX}${tabId}`);
});

chrome.runtime.onStartup.addListener(async () => {
  const all = await chrome.storage.local.get(null);
  const now = Date.now();
  const staleKeys = [];
  for (const [key, value] of Object.entries(all)) {
    if (key.startsWith(HEADER_KEY_PREFIX) && value?.capturedAt && now - value.capturedAt > MAX_HEADER_AGE_MS) {
      staleKeys.push(key);
    }
  }
  if (staleKeys.length) chrome.storage.local.remove(staleKeys);
});
