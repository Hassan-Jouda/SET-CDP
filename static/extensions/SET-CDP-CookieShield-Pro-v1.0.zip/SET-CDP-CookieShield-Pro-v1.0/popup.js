
let currentTab = null;
let currentUrl = null;
let currentOrigin = null;
let currentHostname = null;
let cookiesCache = [];
let revealed = new Set();

const $ = (id) => document.getElementById(id);

document.addEventListener("DOMContentLoaded", async () => {
  bindTabs();
  bindEvents();
  await loadCurrentSite();
});

function bindTabs() {
  document.querySelectorAll(".tab").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tabPage").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      $(btn.dataset.tab).classList.add("active");
    });
  });
}

function bindEvents() {
  $("refreshBtn").addEventListener("click", loadCurrentSite);
  $("searchBox").addEventListener("input", renderCookies);
  $("filterSelect").addEventListener("change", renderCookies);
  $("createForm").addEventListener("submit", createCookie);
  $("editForm").addEventListener("submit", saveEditCookie);
  $("cancelEditBtn").addEventListener("click", () => $("editDialog").close());
  $("deleteSessionBtn").addEventListener("click", () => bulkDelete("session"));
  $("deleteInsecureBtn").addEventListener("click", () => bulkDelete("insecure"));
  $("deleteAllBtn").addEventListener("click", () => bulkDelete("all"));
  $("downloadAuditBtn").addEventListener("click", downloadAuditReport);
}

async function loadCurrentSite() {
  try {
    let tabs = await chrome.tabs.query({active: true, currentWindow: true});
    currentTab = tabs[0];
    currentUrl = new URL(currentTab.url);
    currentOrigin = currentUrl.origin;
    currentHostname = currentUrl.hostname;

    if (!["http:", "https:"].includes(currentUrl.protocol)) {
      $("siteInfo").textContent = "هذه الصفحة داخلية في المتصفح ولا يمكن إدارة كوكيز لها.";
      cookiesCache = [];
      renderAll();
      return;
    }

    $("siteInfo").textContent = `${currentHostname}`;
    cookiesCache = await chrome.cookies.getAll({url: currentOrigin});
    revealed.clear();
    renderAll();
  } catch (e) {
    $("siteInfo").textContent = "تعذر قراءة الموقع الحالي.";
    showToast("تعذر تحميل بيانات الكوكيز.");
    console.error(e);
  }
}

function renderAll() {
  const audit = analyzeCookies(cookiesCache);
  renderScore(audit);
  renderStats(audit);
  renderCookies();
  renderAudit(audit);
}

function analyzeCookies(cookies) {
  const total = cookies.length;
  const insecure = cookies.filter(c => !c.secure).length;
  const noHttpOnly = cookies.filter(c => !c.httpOnly).length;
  const sameSiteIssues = cookies.filter(c => !c.sameSite || c.sameSite === "unspecified" || c.sameSite === "no_restriction").length;
  const session = cookies.filter(c => c.session).length;
  const longLived = cookies.filter(c => !c.session && c.expirationDate && (c.expirationDate - Date.now()/1000) > 60*60*24*180).length;
  const thirdPartyLike = cookies.filter(c => normalizeDomain(c.domain) !== currentHostname && currentHostname && !currentHostname.endsWith("." + normalizeDomain(c.domain))).length;

  let score = 100;
  if (total === 0) score = 100;
  score -= Math.min(35, insecure * 8);
  score -= Math.min(25, noHttpOnly * 5);
  score -= Math.min(20, sameSiteIssues * 5);
  score -= Math.min(10, longLived * 3);
  score -= Math.min(10, thirdPartyLike * 3);
  score = Math.max(0, Math.round(score));

  let level = "Excellent";
  if (score < 40) level = "High Risk";
  else if (score < 65) level = "Medium Risk";
  else if (score < 85) level = "Good";

  return {total, insecure, noHttpOnly, sameSiteIssues, session, longLived, thirdPartyLike, score, level};
}

function renderScore(audit) {
  $("scoreValue").textContent = audit.score;
  $("riskLevel").textContent = audit.level;
  const circle = document.querySelector(".scoreCircle");
  const deg = Math.round(audit.score * 3.6);
  let color = "#10b981";
  if (audit.score < 40) color = "#dc2626";
  else if (audit.score < 65) color = "#f97316";
  else if (audit.score < 85) color = "#0ea5e9";
  circle.style.background = `conic-gradient(${color} ${deg}deg, #e2e8f0 ${deg}deg)`;

  $("scoreText").textContent = audit.total === 0
    ? "لا توجد كوكيز للموقع الحالي."
    : `تم تحليل ${audit.total} Cookie. الأفضل تفعيل Secure و HttpOnly و SameSite للحماية.`;
}

function renderStats(audit) {
  $("totalCookies").textContent = audit.total;
  $("insecureCookies").textContent = audit.insecure;
  $("noHttpOnly").textContent = audit.noHttpOnly;
  $("sameSiteIssues").textContent = audit.sameSiteIssues;
}

function renderCookies() {
  const list = $("cookieList");
  const empty = $("emptyState");
  list.innerHTML = "";

  let q = $("searchBox").value.trim().toLowerCase();
  let filter = $("filterSelect").value;

  let data = cookiesCache.filter(c => {
    let text = `${c.name} ${c.domain} ${c.path}`.toLowerCase();
    if (q && !text.includes(q)) return false;

    if (filter === "secure") return c.secure;
    if (filter === "insecure") return !c.secure;
    if (filter === "httponly") return c.httpOnly;
    if (filter === "nohttponly") return !c.httpOnly;
    if (filter === "session") return c.session;
    if (filter === "risk") return isRisky(c);
    return true;
  });

  if (!data.length) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  data.forEach((c, idx) => {
    const key = cookieKey(c);
    const showValue = revealed.has(key);
    const div = document.createElement("div");
    div.className = "cookieCard";

    div.innerHTML = `
      <div class="cookieHead">
        <div>
          <div class="cookieName">${escapeHtml(c.name)}</div>
          <div class="cookieDomain">${escapeHtml(c.domain)}${escapeHtml(c.path || "/")}</div>
        </div>
      </div>
      <div class="badges">
        <span class="badge ${c.secure ? "good" : "bad"}">${c.secure ? "Secure" : "No Secure"}</span>
        <span class="badge ${c.httpOnly ? "good" : "warn"}">${c.httpOnly ? "HttpOnly" : "No HttpOnly"}</span>
        <span class="badge ${sameSiteClass(c.sameSite)}">SameSite: ${escapeHtml(c.sameSite || "unspecified")}</span>
        <span class="badge ${c.session ? "warn" : "good"}">${c.session ? "Session" : "Persistent"}</span>
      </div>
      <div class="valueBox">${showValue ? escapeHtml(c.value || "") : maskValue(c.value || "")}</div>
      <div class="cardActions">
        <button class="softBtn revealBtn">${showValue ? "إخفاء القيمة" : "إظهار القيمة"}</button>
        <button class="softBtn editBtn">تعديل</button>
        <button class="softBtn dangerBtn deleteBtn">حذف</button>
      </div>
    `;

    div.querySelector(".revealBtn").addEventListener("click", () => {
      if (revealed.has(key)) revealed.delete(key);
      else revealed.add(key);
      renderCookies();
    });

    div.querySelector(".editBtn").addEventListener("click", () => openEditDialog(c));
    div.querySelector(".deleteBtn").addEventListener("click", () => deleteCookie(c));

    list.appendChild(div);
  });
}

function renderAudit(audit) {
  const box = $("auditBox");
  const items = [
    {
      title: "Secure Flag",
      value: audit.insecure === 0 ? "جيد" : `${audit.insecure} Cookie بدون Secure`,
      desc: "يفضل تفعيل Secure حتى لا تُرسل الكوكيز عبر HTTP غير مشفر."
    },
    {
      title: "HttpOnly Flag",
      value: audit.noHttpOnly === 0 ? "جيد" : `${audit.noHttpOnly} Cookie بدون HttpOnly`,
      desc: "HttpOnly يقلل خطر قراءة الكوكيز عبر JavaScript في حال وجود XSS."
    },
    {
      title: "SameSite Policy",
      value: audit.sameSiteIssues === 0 ? "جيد" : `${audit.sameSiteIssues} Cookie تحتاج مراجعة SameSite`,
      desc: "SameSite=Lax أو Strict يساعد في تقليل مخاطر CSRF."
    },
    {
      title: "Expiration Review",
      value: audit.longLived === 0 ? "جيد" : `${audit.longLived} Cookie طويلة المدة`,
      desc: "الكوكيز الحساسة لا يُفضل أن تبقى مدة طويلة بدون حاجة."
    },
    {
      title: "Third-party-like Cookies",
      value: audit.thirdPartyLike === 0 ? "لا توجد مؤشرات واضحة" : `${audit.thirdPartyLike} Cookie من نطاق مختلف`,
      desc: "وجود كوكيز مرتبطة بنطاقات أخرى قد يكون طبيعياً للإعلانات والتحليلات، لكنه مهم للخصوصية."
    }
  ];

  box.innerHTML = items.map(i => `
    <div class="auditItem">
      <b>${escapeHtml(i.title)} — ${escapeHtml(i.value)}</b>
      <p>${escapeHtml(i.desc)}</p>
    </div>
  `).join("");
}

async function createCookie(e) {
  e.preventDefault();
  const fd = new FormData(e.target);
  const details = formToCookieDetails(fd);
  try {
    await chrome.cookies.set(details);
    showToast("تم إنشاء Cookie بنجاح.");
    e.target.reset();
    e.target.path.value = "/";
    e.target.days.value = 7;
    e.target.secure.checked = true;
    await loadCurrentSite();
  } catch (err) {
    showToast("فشل إنشاء Cookie. راجع البيانات.");
    console.error(err);
  }
}

function openEditDialog(c) {
  const f = $("editForm");
  f.oldName.value = c.name;
  f.oldDomain.value = c.domain;
  f.oldPath.value = c.path || "/";
  f.name.value = c.name;
  f.value.value = c.value || "";
  f.path.value = c.path || "/";
  f.days.value = c.session || !c.expirationDate ? 7 : Math.max(0, Math.ceil((c.expirationDate - Date.now()/1000) / 86400));
  f.sameSite.value = c.sameSite || "unspecified";
  f.secure.checked = !!c.secure;
  f.httpOnly.checked = !!c.httpOnly;
  $("editDialog").showModal();
}

async function saveEditCookie(e) {
  e.preventDefault();
  const f = e.target;
  const oldCookie = {
    name: f.oldName.value,
    domain: f.oldDomain.value,
    path: f.oldPath.value
  };

  try {
    await removeCookieByParts(oldCookie.name, oldCookie.domain, oldCookie.path);
    const fd = new FormData(f);
    const details = formToCookieDetails(fd);
    await chrome.cookies.set(details);
    $("editDialog").close();
    showToast("تم تعديل Cookie.");
    await loadCurrentSite();
  } catch (err) {
    showToast("فشل التعديل.");
    console.error(err);
  }
}

function formToCookieDetails(fd) {
  let days = Number(fd.get("days") || 0);
  let sameSite = fd.get("sameSite") || "lax";
  let secure = fd.get("secure") === "on";
  if (sameSite === "no_restriction") secure = true; // Chrome requires Secure for SameSite=None

  let details = {
    url: currentOrigin,
    name: String(fd.get("name") || ""),
    value: String(fd.get("value") || ""),
    path: String(fd.get("path") || "/"),
    secure,
    httpOnly: fd.get("httpOnly") === "on",
    sameSite
  };

  if (days > 0) {
    details.expirationDate = Math.floor(Date.now()/1000) + days * 86400;
  }

  return details;
}

async function deleteCookie(c) {
  if (!confirm(`حذف Cookie: ${c.name} ؟`)) return;
  try {
    await removeCookieByParts(c.name, c.domain, c.path || "/");
    showToast("تم الحذف.");
    await loadCurrentSite();
  } catch (e) {
    showToast("فشل الحذف.");
    console.error(e);
  }
}

async function removeCookieByParts(name, domain, path) {
  const protocol = currentUrl.protocol;
  let cleanDomain = normalizeDomain(domain);
  let url = `${protocol}//${cleanDomain}${path || "/"}`;
  return chrome.cookies.remove({url, name});
}

async function bulkDelete(type) {
  let targets = [];
  if (type === "all") targets = cookiesCache;
  if (type === "session") targets = cookiesCache.filter(c => c.session);
  if (type === "insecure") targets = cookiesCache.filter(c => !c.secure);

  if (!targets.length) {
    showToast("لا يوجد شيء للحذف.");
    return;
  }

  const msg = type === "all"
    ? `سيتم حذف كل كوكيز الموقع الحالي (${targets.length}). هل أنت متأكد؟`
    : `سيتم حذف ${targets.length} Cookie. هل أنت متأكد؟`;

  if (!confirm(msg)) return;

  for (const c of targets) {
    try { await removeCookieByParts(c.name, c.domain, c.path || "/"); } catch(e) {}
  }

  showToast("تم تنفيذ الحذف.");
  await loadCurrentSite();
}

function downloadAuditReport() {
  const audit = analyzeCookies(cookiesCache);
  const safeCookies = cookiesCache.map(c => ({
    name: c.name,
    domain: c.domain,
    path: c.path,
    secure: c.secure,
    httpOnly: c.httpOnly,
    sameSite: c.sameSite,
    session: c.session,
    expirationDate: c.expirationDate || null,
    valueIncluded: false
  }));

  const report = {
    tool: "SET-CDP CookieShield Pro",
    version: "1.0.0",
    generatedAt: new Date().toISOString(),
    site: currentHostname,
    score: audit.score,
    level: audit.level,
    summary: audit,
    cookies: safeCookies,
    note: "Cookie values are intentionally excluded from this audit report for privacy and safety."
  };

  const blob = new Blob([JSON.stringify(report, null, 2)], {type: "application/json"});
  const url = URL.createObjectURL(blob);
  chrome.downloads.download({
    url,
    filename: `cookieshield-audit-${currentHostname || "site"}-${Date.now()}.json`,
    saveAs: true
  });
}

function isRisky(c) {
  return !c.secure || !c.httpOnly || !c.sameSite || c.sameSite === "unspecified" || c.sameSite === "no_restriction";
}

function sameSiteClass(s) {
  if (s === "strict" || s === "lax") return "good";
  if (s === "no_restriction") return "warn";
  return "bad";
}

function maskValue(v) {
  if (!v) return "(empty)";
  if (v.length <= 8) return "•".repeat(v.length);
  return v.slice(0, 3) + "•".repeat(Math.min(24, v.length - 6)) + v.slice(-3);
}

function cookieKey(c) {
  return `${c.name}|${c.domain}|${c.path}`;
}

function normalizeDomain(d) {
  return String(d || "").replace(/^\./, "");
}

function escapeHtml(str) {
  return String(str || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function showToast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.remove("hidden");
  setTimeout(() => t.classList.add("hidden"), 2200);
}
