
(function () {
  const STYLE_ID = "set-cdp-adshield-style";
  let hiddenCount = 0;

  const selectors = [
    '[id*="ad-"]',
    '[id*="_ad_"]',
    '[id^="ad_"]',
    '[id$="_ad"]',
    '[class*=" ad-"]',
    '[class*=" ads-"]',
    '[class*="advert"]',
    '[class*="sponsor"]',
    '[class*="promoted"]',
    'iframe[src*="doubleclick"]',
    'iframe[src*="googlesyndication"]',
    'iframe[src*="googleadservices"]',
    'iframe[src*="adnxs"]',
    'iframe[src*="taboola"]',
    'iframe[src*="outbrain"]',
    'div[data-ad]',
    'div[data-ad-slot]',
    'ins.adsbygoogle',
    '.adsbygoogle',
    '.ad-container',
    '.ad-wrapper',
    '.advertisement',
    '.sponsored',
    '.sponsor',
    '.promoted-post',

    /* YouTube cosmetic cleaning: effectiveness may change when YouTube updates UI */
    'ytd-display-ad-renderer',
    'ytd-promoted-sparkles-web-renderer',
    'ytd-promoted-video-renderer',
    'ytd-ad-slot-renderer',
    'ytd-in-feed-ad-layout-renderer',
    'ytd-companion-slot-renderer',
    '#player-ads',
    '#masthead-ad',
    '.ytp-ad-module',
    '.video-ads',
    '.ytp-ad-player-overlay',
    '.ytp-ad-overlay-container',

    /* Facebook / social promoted blocks */
    '[aria-label="Sponsored"]',
    'div[data-pagelet*="FeedUnit"] a[href*="/ads/"]'
  ];

  const styleText = selectors.join(",\n") + `
  {
    display: none !important;
    visibility: hidden !important;
    opacity: 0 !important;
    pointer-events: none !important;
    height: 0 !important;
    min-height: 0 !important;
    max-height: 0 !important;
    overflow: hidden !important;
  }`;

  async function isEnabled() {
    try {
      const { enabled = true, cosmetic = true } = await chrome.storage.local.get(["enabled", "cosmetic"]);
      return enabled && cosmetic;
    } catch (e) {
      return true;
    }
  }

  async function injectCSS() {
    if (!(await isEnabled())) return;
    if (document.getElementById(STYLE_ID)) return;
    const s = document.createElement("style");
    s.id = STYLE_ID;
    s.textContent = styleText;
    (document.documentElement || document.head).appendChild(s);
  }

  function likelyAdElement(el) {
    if (!el || el.nodeType !== 1) return false;
    const text = [
      el.id || "",
      el.className || "",
      el.getAttribute("aria-label") || "",
      el.getAttribute("data-ad") || "",
      el.getAttribute("data-testid") || ""
    ].join(" ").toLowerCase();

    return /(^|\s)(ad|ads|advert|advertisement|sponsored|promoted)(\s|$|-|_)/i.test(text)
      || text.includes("adsbygoogle")
      || text.includes("doubleclick")
      || text.includes("googlesyndication");
  }

  async function cleanDOM() {
    if (!(await isEnabled())) return;
    try {
      document.querySelectorAll(selectors.join(",")).forEach(el => {
        if (!el.dataset.adshieldHidden) {
          el.dataset.adshieldHidden = "1";
          hiddenCount++;
        }
        el.style.setProperty("display", "none", "important");
      });

      document.querySelectorAll("iframe, div, aside, section").forEach(el => {
        if (likelyAdElement(el)) {
          if (!el.dataset.adshieldHidden) {
            el.dataset.adshieldHidden = "1";
            hiddenCount++;
          }
          el.style.setProperty("display", "none", "important");
        }
      });

      chrome.storage.local.set({ lastHiddenCount: hiddenCount, lastCleanedHost: location.hostname });
    } catch (e) {}
  }

  injectCSS();
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", cleanDOM);
  } else {
    cleanDOM();
  }

  const observer = new MutationObserver(() => {
    cleanDOM();
  });

  try {
    observer.observe(document.documentElement, { childList: true, subtree: true });
  } catch (e) {}

  chrome.storage.onChanged.addListener((changes) => {
    if (changes.enabled || changes.cosmetic) {
      location.reload();
    }
  });
})();
