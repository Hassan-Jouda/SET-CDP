'use strict';

const HEADER_KEY_PREFIX = 'webshield_headers_';
const COMMON_PASSWORDS = new Set([
  'password','123456','123456789','12345678','qwerty','abc123','111111','123123','admin','letmein',
  'welcome','iloveyou','monkey','dragon','football','baseball','qwerty123','passw0rd','password1',
  'admin123','000000','654321','1234','12345','112233','qazwsx','qwertyuiop','user','login'
]);
const SHORTENERS = new Set(['bit.ly','tinyurl.com','t.co','goo.gl','ow.ly','is.gd','buff.ly','cutt.ly','rebrand.ly','lnkd.in','s.id','rb.gy','shorturl.at','soo.gd']);
const TRACKER_PATTERNS = [
  { name: 'Google Analytics', pattern: /google-analytics\.com|analytics\.google\.com|gtag\/js/i },
  { name: 'Google Tag Manager', pattern: /googletagmanager\.com/i },
  { name: 'DoubleClick', pattern: /doubleclick\.net/i },
  { name: 'Facebook Pixel', pattern: /connect\.facebook\.net|fbevents\.js/i },
  { name: 'Hotjar', pattern: /hotjar\.com|static\.hotjar\.com/i },
  { name: 'Microsoft Clarity', pattern: /clarity\.ms/i },
  { name: 'Mixpanel', pattern: /mixpanel\.com/i },
  { name: 'Segment', pattern: /segment\.com|segment\.io/i },
  { name: 'FullStory', pattern: /fullstory\.com/i },
  { name: 'TikTok Pixel', pattern: /analytics\.tiktok\.com/i },
  { name: 'Yandex Metrica', pattern: /mc\.yandex\.ru/i }
];
const SUSPICIOUS_TLDS = new Set(['zip','mov','click','top','xyz','gq','tk','ml','cf','work','quest','cam','rest','country']);
const BRAND_HINTS = ['google','facebook','meta','paypal','microsoft','apple','instagram','whatsapp','netflix','amazon','openai','linkedin','bank'];

const state = {
  currentTab: null,
  lastUrlAnalysis: null,
  lastPrivacy: null,
  lastHeaders: null,
  lastEmail: null,
  lastHash: null,
  lastQr: null
};

function $(id) { return document.getElementById(id); }
function setStatus(message) { $('status').textContent = message; }
function clamp(n, min, max) { return Math.max(min, Math.min(max, n)); }
function escapeHtml(str = '') {
  return String(str).replace(/[&<>'"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' }[c]));
}
function formatBytes(bytes) {
  if (!bytes) return '0 B';
  const units = ['B','KB','MB','GB'];
  let i = 0, value = bytes;
  while (value >= 1024 && i < units.length - 1) { value /= 1024; i++; }
  return `${value.toFixed(i ? 2 : 0)} ${units[i]}`;
}
function finding(type, text) {
  return `<div class="finding ${type}">${escapeHtml(text)}</div>`;
}
function renderFindings(targetId, items) {
  $(targetId).innerHTML = items.length ? items.map((i) => finding(i.type, i.text)).join('') : finding('safe', 'لا توجد مؤشرات خطورة واضحة في هذا الفحص.');
}
function meterColor(score, inverse = false) {
  const s = inverse ? 100 - score : score;
  if (s >= 75) return 'var(--safe)';
  if (s >= 45) return 'var(--warn)';
  return 'var(--danger)';
}
function setMeter(id, score, inverse = false) {
  const el = $(id);
  el.style.width = `${clamp(score, 0, 100)}%`;
  el.style.background = meterColor(score, inverse);
}
function riskLevel(score) {
  if (score >= 75) return 'High';
  if (score >= 45) return 'Medium';
  if (score >= 20) return 'Low';
  return 'Safe';
}
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}
function safeUrl(raw) {
  try { return new URL(raw); } catch { return null; }
}
function getRegistrableGuess(hostname) {
  const parts = hostname.split('.').filter(Boolean);
  if (parts.length <= 2) return hostname;
  return parts.slice(-2).join('.');
}
function isIpHost(hostname) {
  return /^(\d{1,3}\.){3}\d{1,3}$/.test(hostname) || /^\[[0-9a-f:]+\]$/i.test(hostname);
}

function analyzeUrl(rawUrl) {
  const findings = [];
  const positives = [];
  let score = 0;
  const parsed = safeUrl((rawUrl || '').trim());

  if (!parsed) {
    return { valid: false, score: 100, level: 'Invalid', domain: '--', findings: [{ type: 'danger', text: 'الرابط غير صالح أو غير مكتمل.' }] };
  }

  const protocol = parsed.protocol.replace(':','');
  const hostname = parsed.hostname.toLowerCase();
  const path = parsed.pathname + parsed.search + parsed.hash;
  const domainGuess = getRegistrableGuess(hostname);
  const tld = hostname.split('.').pop() || '';
  const subdomainCount = Math.max(0, hostname.split('.').length - 2);
  const hyphens = (hostname.match(/-/g) || []).length;
  const digits = (hostname.match(/\d/g) || []).length;

  if (protocol !== 'https') {
    score += 25;
    findings.push({ type: 'danger', text: 'الرابط لا يستخدم HTTPS. لا تدخل بيانات حساسة في صفحات HTTP.' });
  } else {
    positives.push({ type: 'safe', text: 'الرابط يستخدم HTTPS.' });
  }
  if (isIpHost(hostname)) {
    score += 25;
    findings.push({ type: 'danger', text: 'الرابط يستخدم IP بدلاً من اسم نطاق واضح، وهذا مؤشر شائع في الروابط المشبوهة.' });
  }
  if (rawUrl.includes('@')) {
    score += 20;
    findings.push({ type: 'danger', text: 'الرابط يحتوي على الرمز @، وقد يخفي الوجهة الحقيقية للرابط.' });
  }
  if (hostname.includes('xn--')) {
    score += 20;
    findings.push({ type: 'warn', text: 'تم اكتشاف Punycode، قد يكون الرابط يستخدم تشابه الحروف Homograph Attack.' });
  }
  if (SHORTENERS.has(domainGuess) || SHORTENERS.has(hostname)) {
    score += 18;
    findings.push({ type: 'warn', text: 'الرابط يستخدم خدمة اختصار روابط. افحص الوجهة النهائية قبل فتحه.' });
  }
  if (SUSPICIOUS_TLDS.has(tld)) {
    score += 12;
    findings.push({ type: 'warn', text: `امتداد النطاق .${tld} قد يستخدم كثيراً في الحملات المشبوهة. ليس دليلاً قاطعاً لكنه يستحق الحذر.` });
  }
  if (subdomainCount >= 3) {
    score += 12;
    findings.push({ type: 'warn', text: 'عدد كبير من النطاقات الفرعية قد يستخدم لإخفاء النطاق الحقيقي.' });
  }
  if (hyphens >= 3) {
    score += 10;
    findings.push({ type: 'warn', text: 'النطاق يحتوي على شرطات كثيرة، وهذا قد يدل على نطاق مقلد.' });
  }
  if (digits >= 4) {
    score += 8;
    findings.push({ type: 'warn', text: 'النطاق يحتوي على أرقام كثيرة، وهذا قد يكون مؤشراً على نطاق عشوائي.' });
  }
  if (rawUrl.length > 160) {
    score += 10;
    findings.push({ type: 'warn', text: 'الرابط طويل جداً، وقد يخفي معاملات أو إعادة توجيه مشبوهة.' });
  }
  if (/[?&](redirect|url|next|continue|return|target)=/i.test(rawUrl)) {
    score += 10;
    findings.push({ type: 'warn', text: 'الرابط يحتوي على معامل إعادة توجيه. تحقق من الوجهة النهائية.' });
  }
  if (/login|verify|secure|account|update|confirm|wallet|bank/i.test(path) && protocol !== 'https') {
    score += 15;
    findings.push({ type: 'danger', text: 'الرابط يبدو متعلقاً بتسجيل دخول أو تحقق لكنه غير مشفر.' });
  }

  const brandLike = BRAND_HINTS.find((brand) => hostname.includes(brand) && !hostname.endsWith(`${brand}.com`) && hostname !== `${brand}.com`);
  if (brandLike && /-|\d|secure|login|verify|account/i.test(hostname)) {
    score += 14;
    findings.push({ type: 'warn', text: `النطاق يحتوي على كلمة شبيهة بعلامة معروفة (${brandLike}) مع مؤشرات تقليد. تحقق يدوياً من النطاق الرسمي.` });
  }

  if (!findings.length) positives.push({ type: 'safe', text: 'لم يتم العثور على مؤشرات تصيد واضحة في بنية الرابط.' });

  score = clamp(score, 0, 100);
  const combined = [...findings, ...positives];
  return { valid: true, score, level: riskLevel(score), domain: domainGuess, hostname, protocol, findings: combined, rawUrl };
}

function updateUrlUI(analysis) {
  $('urlScore').textContent = analysis.score;
  $('urlLevel').textContent = analysis.level;
  $('urlDomain').textContent = analysis.domain || '--';
  setMeter('urlMeter', analysis.score, true);
  renderFindings('urlFindings', analysis.findings);
  $('overallScore').textContent = analysis.score;
}

function renderManualUrl() {
  const value = $('manualUrl').value.trim();
  const analysis = analyzeUrl(value);
  renderFindings('manualUrlResult', analysis.findings);
}

function estimatePasswordPool(password) {
  let pool = 0;
  if (/[a-z]/.test(password)) pool += 26;
  if (/[A-Z]/.test(password)) pool += 26;
  if (/\d/.test(password)) pool += 10;
  if (/[^A-Za-z0-9]/.test(password)) pool += 33;
  return pool || 1;
}
function formatCrackTime(seconds) {
  if (!Number.isFinite(seconds) || seconds > 1e18) return 'Millions+ years';
  if (seconds < 1) return '< 1 sec';
  const units = [
    ['year', 31557600], ['day', 86400], ['hour', 3600], ['min', 60], ['sec', 1]
  ];
  for (const [name, value] of units) {
    if (seconds >= value) {
      const amount = seconds / value;
      return `${amount >= 10 ? Math.round(amount) : amount.toFixed(1)} ${name}${amount >= 2 ? 's' : ''}`;
    }
  }
  return `${Math.round(seconds)} sec`;
}
function hasSequence(pwd) {
  const lower = pwd.toLowerCase();
  const sequences = ['abcdefghijklmnopqrstuvwxyz', 'qwertyuiopasdfghjklzxcvbnm', '0123456789'];
  return sequences.some(seq => {
    for (let i = 0; i <= seq.length - 4; i++) {
      const part = seq.slice(i, i + 4);
      if (lower.includes(part) || lower.includes(part.split('').reverse().join(''))) return true;
    }
    return false;
  });
}
function analyzePassword(password) {
  const findings = [];
  if (!password) return { score: 0, strength: '--', entropy: 0, crack: '--', findings: [{ type: 'info', text: 'اكتب كلمة مرور لبدء التحليل.' }] };
  const pool = estimatePasswordPool(password);
  let entropy = Math.log2(Math.pow(pool, password.length));
  let score = clamp(entropy, 0, 100);
  const lower = password.toLowerCase();

  if (password.length < 8) { score -= 35; findings.push({ type: 'danger', text: 'كلمة المرور قصيرة جداً. استخدم 12 خانة على الأقل.' }); }
  else if (password.length < 12) { score -= 15; findings.push({ type: 'warn', text: 'الطول مقبول لكنه ليس مثالياً. الأفضل 12–16 خانة فأكثر.' }); }
  else findings.push({ type: 'safe', text: 'الطول جيد.' });

  if (COMMON_PASSWORDS.has(lower)) { score -= 60; findings.push({ type: 'danger', text: 'كلمة المرور موجودة ضمن كلمات مرور شائعة جداً.' }); }
  if (!/[a-z]/.test(password)) { score -= 8; findings.push({ type: 'warn', text: 'لا تحتوي على أحرف صغيرة.' }); }
  if (!/[A-Z]/.test(password)) { score -= 8; findings.push({ type: 'warn', text: 'لا تحتوي على أحرف كبيرة.' }); }
  if (!/\d/.test(password)) { score -= 8; findings.push({ type: 'warn', text: 'لا تحتوي على أرقام.' }); }
  if (!/[^A-Za-z0-9]/.test(password)) { score -= 10; findings.push({ type: 'warn', text: 'لا تحتوي على رموز خاصة.' }); }
  if (/(.)\1{2,}/.test(password)) { score -= 12; findings.push({ type: 'warn', text: 'يوجد تكرار واضح للأحرف.' }); }
  if (hasSequence(password)) { score -= 14; findings.push({ type: 'warn', text: 'تحتوي على تسلسل معروف مثل 1234 أو abcd أو qwerty.' }); }
  if (/password|admin|login|user|welcome|gaza|palestine/i.test(password)) { score -= 12; findings.push({ type: 'warn', text: 'تحتوي على كلمة يمكن تخمينها بسهولة.' }); }
  if (score >= 85) findings.push({ type: 'safe', text: 'قوية جداً. يمكن استخدامها بشرط ألا تكون معاد استخدامها في مواقع أخرى.' });

  score = clamp(Math.round(score), 0, 100);
  const guessesPerSecond = 1e10;
  const crackSeconds = Math.pow(2, Math.min(entropy, 120)) / guessesPerSecond;
  let strength = 'Weak';
  if (score >= 85) strength = 'Very Strong';
  else if (score >= 70) strength = 'Strong';
  else if (score >= 45) strength = 'Medium';

  return { score, strength, entropy: Math.round(entropy), crack: formatCrackTime(crackSeconds), findings };
}
function updatePasswordUI() {
  const result = analyzePassword($('passwordInput').value);
  $('passwordStrength').textContent = result.strength;
  $('passwordEntropy').textContent = `${result.entropy} bits`;
  $('crackTime').textContent = result.crack;
  setMeter('passwordMeter', result.score);
  renderFindings('passwordFindings', result.findings);
}
function secureRandomInt(max) {
  const array = new Uint32Array(1);
  const limit = Math.floor(0xFFFFFFFF / max) * max;
  do { crypto.getRandomValues(array); } while (array[0] >= limit);
  return array[0] % max;
}
function generatePassword() {
  const length = Number($('genLength').value);
  const sets = [];
  if ($('genUpper').checked) sets.push('ABCDEFGHIJKLMNOPQRSTUVWXYZ');
  if ($('genLower').checked) sets.push('abcdefghijklmnopqrstuvwxyz');
  if ($('genNumbers').checked) sets.push('0123456789');
  if ($('genSymbols').checked) sets.push('!@#$%^&*()_+-=[]{}|;:,.<>?');
  if (!sets.length) { setStatus('اختر نوعاً واحداً على الأقل.'); return; }
  const all = sets.join('');
  const chars = [];
  for (const set of sets) chars.push(set[secureRandomInt(set.length)]);
  while (chars.length < length) chars.push(all[secureRandomInt(all.length)]);
  for (let i = chars.length - 1; i > 0; i--) {
    const j = secureRandomInt(i + 1);
    [chars[i], chars[j]] = [chars[j], chars[i]];
  }
  $('generatedPassword').value = chars.join('');
  setStatus('تم توليد كلمة مرور قوية محلياً.');
}

function scanPageDom() {
  const pageHost = location.hostname;
  const sameHost = (url) => {
    try { return new URL(url, location.href).hostname === pageHost; } catch { return true; }
  };
  const scripts = [...document.scripts].map(s => s.src).filter(Boolean);
  const iframes = [...document.querySelectorAll('iframe')].map(i => i.src).filter(Boolean);
  const images = [...document.images].map(i => i.src).filter(Boolean);
  const forms = [...document.forms].map(form => ({
    action: form.action || location.href,
    method: (form.method || 'get').toLowerCase(),
    hasPassword: !!form.querySelector('input[type="password"]'),
    insecureAction: (form.action || location.href).startsWith('http://'),
    externalAction: !sameHost(form.action || location.href)
  }));
  const allSources = [...scripts, ...iframes, ...images];
  const thirdPartyScripts = scripts.filter(src => !sameHost(src));
  const trackerHits = [];
  for (const source of allSources) {
    for (const tracker of [
      ['Google Analytics', /google-analytics\.com|analytics\.google\.com|gtag\/js/i],
      ['Google Tag Manager', /googletagmanager\.com/i],
      ['DoubleClick', /doubleclick\.net/i],
      ['Facebook Pixel', /connect\.facebook\.net|fbevents\.js/i],
      ['Hotjar', /hotjar\.com|static\.hotjar\.com/i],
      ['Microsoft Clarity', /clarity\.ms/i],
      ['Mixpanel', /mixpanel\.com/i],
      ['Segment', /segment\.com|segment\.io/i],
      ['FullStory', /fullstory\.com/i],
      ['TikTok Pixel', /analytics\.tiktok\.com/i],
      ['Yandex Metrica', /mc\.yandex\.ru/i]
    ]) {
      if (tracker[1].test(source)) trackerHits.push(tracker[0]);
    }
  }
  return {
    host: pageHost,
    title: document.title,
    scriptsCount: scripts.length,
    thirdPartyScriptsCount: thirdPartyScripts.length,
    thirdPartyScripts: thirdPartyScripts.slice(0, 12),
    iframesCount: iframes.length,
    forms,
    passwordForms: forms.filter(f => f.hasPassword).length,
    insecureForms: forms.filter(f => f.insecureAction).length,
    externalForms: forms.filter(f => f.externalAction).length,
    trackers: [...new Set(trackerHits)]
  };
}
async function scanPrivacy() {
  try {
    const tab = state.currentTab || await getCurrentTab();
    const [domResult] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: scanPageDom });
    const dom = domResult.result;
    let cookies = [];
    try { cookies = await chrome.cookies.getAll({ url: tab.url }); } catch { cookies = []; }

    let risk = 0;
    const findings = [];
    if (cookies.length > 20) { risk += 15; findings.push({ type: 'warn', text: `عدد Cookies مرتفع (${cookies.length}).` }); }
    else findings.push({ type: 'safe', text: `عدد Cookies: ${cookies.length}.` });
    const insecureCookies = cookies.filter(c => !c.secure).length;
    const noHttpOnly = cookies.filter(c => !c.httpOnly).length;
    const crossSite = cookies.filter(c => String(c.sameSite).toLowerCase().includes('no_restriction')).length;
    if (insecureCookies) { risk += 10; findings.push({ type: 'warn', text: `${insecureCookies} Cookies لا تستخدم Secure flag.` }); }
    if (noHttpOnly > Math.ceil(cookies.length * 0.7) && cookies.length) { risk += 8; findings.push({ type: 'warn', text: 'نسبة كبيرة من Cookies ليست HttpOnly.' }); }
    if (crossSite) { risk += 10; findings.push({ type: 'warn', text: `${crossSite} Cookies تسمح بسياق طرف ثالث SameSite=None.` }); }
    if (dom.trackers.length) { risk += dom.trackers.length * 9; findings.push({ type: 'warn', text: `Trackers مكتشفة: ${dom.trackers.join(', ')}.` }); }
    else findings.push({ type: 'safe', text: 'لم يتم اكتشاف Trackers معروفة ضمن الصفحة.' });
    if (dom.thirdPartyScriptsCount > 8) { risk += 12; findings.push({ type: 'warn', text: `عدد كبير من Third-party scripts: ${dom.thirdPartyScriptsCount}.` }); }
    if (dom.iframesCount > 3) { risk += 7; findings.push({ type: 'warn', text: `عدد Iframes مرتفع: ${dom.iframesCount}.` }); }
    if (dom.insecureForms) { risk += 20; findings.push({ type: 'danger', text: `${dom.insecureForms} forms ترسل البيانات عبر HTTP.` }); }
    if (dom.externalForms) { risk += 10; findings.push({ type: 'warn', text: `${dom.externalForms} forms ترسل البيانات إلى نطاق خارجي.` }); }
    if (dom.passwordForms) findings.push({ type: 'info', text: `تم اكتشاف ${dom.passwordForms} نموذج يحتوي على حقل كلمة مرور.` });

    const privacyScore = clamp(100 - risk, 0, 100);
    $('privacyScore').textContent = privacyScore;
    $('cookieCount').textContent = cookies.length;
    $('trackerCount').textContent = dom.trackers.length;
    $('thirdPartyScripts').textContent = dom.thirdPartyScriptsCount;
    renderFindings('privacyFindings', findings);
    state.lastPrivacy = { privacyScore, cookies: cookies.length, trackers: dom.trackers, thirdPartyScripts: dom.thirdPartyScriptsCount, findings };
    setStatus('تم فحص الخصوصية محلياً.');
  } catch (err) {
    renderFindings('privacyFindings', [{ type: 'danger', text: `تعذر فحص الصفحة الحالية: ${err.message}` }]);
  }
}

function unfoldHeaders(raw) {
  return raw.replace(/\r\n/g, '\n').replace(/\n[ \t]+/g, ' ');
}
function getHeaderValues(raw, name) {
  const re = new RegExp(`^${name}:\\s*(.*)$`, 'gim');
  const values = [];
  let match;
  while ((match = re.exec(raw)) !== null) values.push(match[1].trim());
  return values;
}
function extractDomains(value) {
  return [...String(value).matchAll(/[a-z0-9.-]+\.[a-z]{2,}/gi)].map(m => m[0].toLowerCase());
}
function authStatus(authResults, key) {
  const re = new RegExp(`${key}\\s*=\\s*([a-z0-9_-]+)`, 'i');
  const match = authResults.match(re);
  if (!match) return 'UNKNOWN';
  return match[1].toUpperCase();
}
function analyzeEmailHeader() {
  const rawInput = $('emailHeaderInput').value.trim();
  if (!rawInput) {
    renderFindings('emailFindings', [{ type: 'info', text: 'الصق Email Header أولاً.' }]);
    return;
  }
  const raw = unfoldHeaders(rawInput);
  const from = getHeaderValues(raw, 'From')[0] || '';
  const replyTo = getHeaderValues(raw, 'Reply-To')[0] || '';
  const returnPath = getHeaderValues(raw, 'Return-Path')[0] || '';
  const authResults = getHeaderValues(raw, 'Authentication-Results').join(' ');
  const received = getHeaderValues(raw, 'Received');
  const messageId = getHeaderValues(raw, 'Message-ID')[0] || '';
  const ips = [...new Set([...raw.matchAll(/\b(?:\d{1,3}\.){3}\d{1,3}\b/g)].map(m => m[0]))];

  const spf = authStatus(authResults, 'spf');
  const dkim = authStatus(authResults, 'dkim');
  const dmarc = authStatus(authResults, 'dmarc');
  $('spfStatus').textContent = spf;
  $('dkimStatus').textContent = dkim;
  $('dmarcStatus').textContent = dmarc;

  let risk = 0;
  const findings = [];
  if (spf === 'PASS') findings.push({ type: 'safe', text: 'SPF PASS حسب Authentication-Results.' }); else { risk += spf === 'UNKNOWN' ? 10 : 25; findings.push({ type: spf === 'UNKNOWN' ? 'warn' : 'danger', text: `SPF: ${spf}.` }); }
  if (dkim === 'PASS') findings.push({ type: 'safe', text: 'DKIM PASS حسب Authentication-Results.' }); else { risk += dkim === 'UNKNOWN' ? 10 : 25; findings.push({ type: dkim === 'UNKNOWN' ? 'warn' : 'danger', text: `DKIM: ${dkim}.` }); }
  if (dmarc === 'PASS') findings.push({ type: 'safe', text: 'DMARC PASS حسب Authentication-Results.' }); else { risk += dmarc === 'UNKNOWN' ? 15 : 30; findings.push({ type: dmarc === 'UNKNOWN' ? 'warn' : 'danger', text: `DMARC: ${dmarc}.` }); }

  const fromDomain = extractDomains(from).pop() || '';
  const replyDomain = extractDomains(replyTo).pop() || '';
  const returnDomain = extractDomains(returnPath).pop() || '';
  const msgDomain = extractDomains(messageId).pop() || '';
  if (replyDomain && fromDomain && replyDomain !== fromDomain) { risk += 15; findings.push({ type: 'warn', text: `Reply-To domain (${replyDomain}) مختلف عن From domain (${fromDomain}).` }); }
  if (returnDomain && fromDomain && returnDomain !== fromDomain) { risk += 10; findings.push({ type: 'warn', text: `Return-Path domain (${returnDomain}) مختلف عن From domain (${fromDomain}).` }); }
  if (msgDomain && fromDomain && msgDomain !== fromDomain) { risk += 6; findings.push({ type: 'info', text: `Message-ID domain (${msgDomain}) مختلف عن From domain (${fromDomain}). قد يكون طبيعياً حسب مزود البريد.` }); }
  if (received.length <= 1) { risk += 8; findings.push({ type: 'warn', text: 'Received chain قصيرة جداً أو غير مكتملة.' }); }
  else findings.push({ type: 'info', text: `Received hops: ${received.length}.` });
  if (ips.length) findings.push({ type: 'info', text: `IPs found: ${ips.slice(0, 8).join(', ')}${ips.length > 8 ? '...' : ''}` });
  if (!authResults) { risk += 20; findings.push({ type: 'warn', text: 'لم يتم العثور على Authentication-Results؛ التحليل سيكون أقل دقة.' }); }

  let label = 'Low';
  if (risk >= 60) label = 'High';
  else if (risk >= 30) label = 'Medium';
  $('spoofRisk').textContent = label;
  renderFindings('emailFindings', findings);
  state.lastEmail = { spf, dkim, dmarc, spoofRisk: label, fromDomain, replyDomain, returnDomain, ips: ips.slice(0, 20), findings };
  setStatus('تم تحليل Email Header محلياً.');
}

async function digestHex(algorithm, buffer) {
  const hash = await crypto.subtle.digest(algorithm, buffer);
  return [...new Uint8Array(hash)].map(b => b.toString(16).padStart(2, '0')).join('');
}
async function hashFile() {
  const file = $('fileInput').files[0];
  if (!file) return;
  $('fileMeta').textContent = `${file.name} | ${formatBytes(file.size)} | ${file.type || 'unknown type'}`;
  setStatus('جارٍ توليد البصمات...');
  const buffer = await file.arrayBuffer();
  const md5 = md5ArrayBuffer(buffer);
  const sha1 = await digestHex('SHA-1', buffer);
  const sha256 = await digestHex('SHA-256', buffer);
  const sha512 = await digestHex('SHA-512', buffer);
  $('md5Hash').textContent = md5;
  $('sha1Hash').textContent = sha1;
  $('sha256Hash').textContent = sha256;
  $('sha512Hash').textContent = sha512;
  state.lastHash = { file: file.name, size: file.size, type: file.type, md5, sha1, sha256, sha512 };
  setStatus('تم توليد Hashes محلياً.');
}

function headerPresent(headers, name) { return !!headers[name.toLowerCase()]; }
function analyzeHeaders(headers) {
  const checks = [
    { key: 'content-security-policy', label: 'Content-Security-Policy', weight: 25, advice: 'يقلل XSS وحقن المحتوى.' },
    { key: 'strict-transport-security', label: 'HSTS', weight: 20, advice: 'يفرض HTTPS ويقلل هجمات downgrade.' },
    { key: 'x-frame-options', label: 'X-Frame-Options', weight: 12, advice: 'يحمي من Clickjacking.' },
    { key: 'x-content-type-options', label: 'X-Content-Type-Options', weight: 10, advice: 'يفضل nosniff لمنع MIME sniffing.' },
    { key: 'referrer-policy', label: 'Referrer-Policy', weight: 10, advice: 'يتحكم بتسريب معلومات الرابط المرجعي.' },
    { key: 'permissions-policy', label: 'Permissions-Policy', weight: 8, advice: 'يقيّد صلاحيات المتصفح مثل الكاميرا والموقع.' },
    { key: 'cross-origin-opener-policy', label: 'COOP', weight: 5, advice: 'يعزز عزل النوافذ بين النطاقات.' },
    { key: 'cross-origin-resource-policy', label: 'CORP', weight: 5, advice: 'يحسن عزل الموارد عبر النطاقات.' },
    { key: 'cross-origin-embedder-policy', label: 'COEP', weight: 5, advice: 'يساعد في عزل المحتوى المضمن.' }
  ];
  let score = 0;
  const findings = [];
  for (const check of checks) {
    if (headerPresent(headers, check.key)) {
      score += check.weight;
      findings.push({ type: 'safe', text: `${check.label}: Present — ${headers[check.key]}` });
    } else {
      findings.push({ type: check.weight >= 15 ? 'danger' : 'warn', text: `${check.label}: Missing — ${check.advice}` });
    }
  }
  if (headers.server) findings.push({ type: 'info', text: `Server header ظاهر: ${headers.server}. يفضل تقليل كشف معلومات الإصدار إن وجدت.` });
  if (headers['x-powered-by']) findings.push({ type: 'warn', text: `X-Powered-By ظاهر: ${headers['x-powered-by']}. يفضل إخفاؤه.` });
  score = clamp(score, 0, 100);
  let grade = 'F';
  if (score >= 95) grade = 'A+';
  else if (score >= 85) grade = 'A';
  else if (score >= 75) grade = 'B+';
  else if (score >= 65) grade = 'B';
  else if (score >= 50) grade = 'C';
  else if (score >= 35) grade = 'D';
  return { score, grade, findings };
}
async function checkHeaders() {
  const tab = state.currentTab || await getCurrentTab();
  const data = await chrome.storage.local.get(`${HEADER_KEY_PREFIX}${tab.id}`);
  const payload = data[`${HEADER_KEY_PREFIX}${tab.id}`];
  if (!payload || !payload.headers) {
    renderFindings('headersFindings', [{ type: 'warn', text: 'لا توجد Headers مخزنة لهذه الصفحة. حدّث الصفحة ثم افتح الإضافة مجدداً.' }]);
    return;
  }
  const analysis = analyzeHeaders(payload.headers);
  $('headersGrade').textContent = analysis.grade;
  $('headersScore').textContent = analysis.score;
  $('headersCount').textContent = Object.keys(payload.headers).length;
  renderFindings('headersFindings', analysis.findings);
  state.lastHeaders = { url: payload.url, grade: analysis.grade, score: analysis.score, headersCount: Object.keys(payload.headers).length, findings: analysis.findings };
  setStatus('تم فحص Security Headers.');
}

async function scanQrFile() {
  const file = $('qrInput').files[0];
  if (!file) return;
  $('qrDecoded').textContent = 'جارٍ قراءة QR...';
  try {
    if (!('BarcodeDetector' in window)) {
      $('qrDecoded').textContent = 'BarcodeDetector غير مدعوم في هذا المتصفح. استخدم Chrome/Edge حديث أو الصق نص QR يدوياً.';
      renderFindings('qrFindings', [{ type: 'warn', text: 'لا يمكن قراءة QR تلقائياً في هذا المتصفح، لكن يمكنك فحص الرابط يدوياً من القسم المجاور.' }]);
      return;
    }
    const detector = new BarcodeDetector({ formats: ['qr_code'] });
    const bitmap = await createImageBitmap(file);
    const codes = await detector.detect(bitmap);
    if (!codes.length) {
      $('qrDecoded').textContent = 'لم يتم العثور على QR Code واضح في الصورة.';
      renderFindings('qrFindings', [{ type: 'warn', text: 'جرّب صورة أوضح أو قص الجزء الذي يحتوي على QR فقط.' }]);
      return;
    }
    const value = codes[0].rawValue || '';
    $('qrDecoded').textContent = value;
    const analysis = /^https?:\/\//i.test(value) ? analyzeUrl(value) : { findings: [{ type: 'info', text: 'QR لا يحتوي على رابط HTTP/HTTPS. افحص النص قبل استخدامه.' }], score: 0 };
    renderFindings('qrFindings', analysis.findings);
    state.lastQr = { value, analysis };
    setStatus('تم فحص QR محلياً.');
  } catch (err) {
    $('qrDecoded').textContent = 'تعذر قراءة QR.';
    renderFindings('qrFindings', [{ type: 'danger', text: err.message }]);
  }
}
function scanQrManual() {
  const value = $('qrManual').value.trim();
  if (!value) { renderFindings('qrManualResult', [{ type: 'info', text: 'الصق نصاً أو رابطاً أولاً.' }]); return; }
  if (/^https?:\/\//i.test(value)) renderFindings('qrManualResult', analyzeUrl(value).findings);
  else renderFindings('qrManualResult', [{ type: 'info', text: 'النص ليس رابط HTTP/HTTPS. راجع محتواه يدوياً قبل استخدامه.' }]);
}

function copyTextById(id) {
  const text = $(id).textContent || $(id).value || '';
  if (!text || text === '--') return;
  navigator.clipboard.writeText(text);
  setStatus('تم النسخ.');
}
async function exportReport() {
  const report = {
    tool: 'SET-CDP WebShield Ultimate',
    version: '3.0.0',
    generatedAt: new Date().toISOString(),
    currentUrl: state.currentTab?.url || null,
    urlAnalysis: state.lastUrlAnalysis,
    privacy: state.lastPrivacy,
    headers: state.lastHeaders,
    email: state.lastEmail,
    fileHash: state.lastHash,
    qr: state.lastQr,
    note: 'All analysis is local where browser APIs allow. This report may include URLs, hashes, and pasted headers selected by the user.'
  };
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `webshield-report-${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
  setStatus('تم تصدير التقرير.');
}
async function clearHistory() {
  await chrome.storage.local.clear();
  setStatus('تم مسح التخزين المحلي للإضافة.');
}

function initTabs() {
  document.querySelectorAll('.tab').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      $(btn.dataset.tab).classList.add('active');
    });
  });
}
function bindEvents() {
  $('scanManualUrl').addEventListener('click', renderManualUrl);
  $('passwordInput').addEventListener('input', updatePasswordUI);
  $('showPassword').addEventListener('change', () => { $('passwordInput').type = $('showPassword').checked ? 'text' : 'password'; });
  $('genLength').addEventListener('input', () => { $('genLengthLabel').textContent = $('genLength').value; });
  $('generatePassword').addEventListener('click', generatePassword);
  $('copyGenerated').addEventListener('click', () => copyTextById('generatedPassword'));
  $('scanPrivacy').addEventListener('click', scanPrivacy);
  $('analyzeEmail').addEventListener('click', analyzeEmailHeader);
  $('fileInput').addEventListener('change', hashFile);
  document.querySelectorAll('[data-copy]').forEach(btn => btn.addEventListener('click', () => copyTextById(btn.dataset.copy)));
  $('checkHeaders').addEventListener('click', checkHeaders);
  $('qrInput').addEventListener('change', scanQrFile);
  $('scanQrManual').addEventListener('click', scanQrManual);
  $('exportReport').addEventListener('click', exportReport);
  $('clearHistory').addEventListener('click', clearHistory);
}
async function initCurrentUrl() {
  try {
    const tab = await getCurrentTab();
    state.currentTab = tab;
    $('currentUrl').textContent = tab.url || 'لا يوجد رابط صفحة.';
    if (tab.url && /^https?:\/\//i.test(tab.url)) {
      const analysis = analyzeUrl(tab.url);
      state.lastUrlAnalysis = analysis;
      updateUrlUI(analysis);
      await chrome.storage.local.set({ lastUrlAnalysis: analysis });
    } else {
      renderFindings('urlFindings', [{ type: 'info', text: 'هذه الصفحة داخلية في المتصفح أو ليست HTTP/HTTPS، لذلك لا يمكن فحصها كرابط ويب.' }]);
    }
  } catch (err) {
    $('currentUrl').textContent = 'تعذر قراءة التبويب الحالي.';
    renderFindings('urlFindings', [{ type: 'danger', text: err.message }]);
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  initTabs();
  bindEvents();
  updatePasswordUI();
  generatePassword();
  await initCurrentUrl();
  setStatus('جاهز — جميع الأدوات تعمل محلياً قدر الإمكان.');
});
