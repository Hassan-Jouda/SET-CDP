// Set up notification alarms
chrome.alarms.onAlarm.addListener((alarm) => {
  const task = JSON.parse(alarm.name);
  chrome.notifications.create({
    type: 'basic',
    iconUrl: 'icons/icon128.png',
    title: 'Task Reminder',
    message: `"${task.text}" is due soon!`,
    priority: 2
  });
});

// Open popup when notification is clicked
chrome.notifications.onClicked.addListener(() => {
  chrome.windows.create({
    url: chrome.runtime.getURL("popup.html"),
    type: "popup",
    width: 400,
    height: 600
  });
});

// Clear old alarms on startup
chrome.runtime.onStartup.addListener(() => {
  chrome.alarms.getAll((alarms) => {
    alarms.forEach(alarm => chrome.alarms.clear(alarm.name));
  });
});

