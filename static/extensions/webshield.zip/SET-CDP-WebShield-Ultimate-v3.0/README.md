# SET-CDP WebShield Ultimate v3.0

إضافة متصفح دفاعية لمشروع تخرج في الأمن السيبراني. تعمل محلياً قدر الإمكان داخل المتصفح وتركز على التوعية والتحليل الدفاعي، وليس جمع بيانات المستخدمين أو تنفيذ هجمات.

## المزايا الرئيسية

### 1) URL Risk Analyzer
- فحص الرابط الحالي تلقائياً.
- فحص روابط يدوية.
- Risk Score من 0 إلى 100.
- كشف HTTP، IP بدلاً من Domain، Punycode/Homograph، Short URLs، علامات @، كثرة subdomains، TLDs مشبوهة، redirect parameters.

### 2) Password Security Analyzer
- تحليل قوة كلمة المرور محلياً.
- Entropy estimate.
- Brute-force crack time estimate.
- كشف كلمات شائعة، تكرار، تسلسلات، نقص التنوع.
- Secure Password Generator باستخدام `crypto.getRandomValues`.

### 3) Privacy Scanner
- فحص Cookies.
- كشف Trackers معروفة مثل Google Analytics و Facebook Pixel و Hotjar و Clarity.
- حساب Third-party scripts.
- فحص forms و password forms و insecure/external form actions.
- Privacy Score.

### 4) Email Header Analyzer
- تحليل SPF / DKIM / DMARC من Authentication-Results.
- مقارنة From / Reply-To / Return-Path / Message-ID domains.
- عرض Received hops و IPs المكتشفة.
- تقدير Spoofing Risk.

### 5) File Hash Generator
- توليد MD5 / SHA1 / SHA256 / SHA512 محلياً.
- مفيد في Digital Forensics و Malware Analysis و Incident Response.

### 6) Security Headers Checker
- يفحص CSP, HSTS, X-Frame-Options, X-Content-Type-Options, Referrer-Policy, Permissions-Policy, COOP, CORP, COEP.
- يعطي Security Grade و Score.
- ملاحظة: يجب تحديث الصفحة بعد تثبيت الإضافة حتى يتم التقاط Headers.

### 7) QR Code Security Scanner
- قراءة QR من صورة عند دعم المتصفح لـ BarcodeDetector.
- تحليل الرابط الموجود داخل QR قبل فتحه.
- يدعم الفحص اليدوي للنص أو الرابط.

## طريقة التثبيت

1. فك ضغط ملف ZIP.
2. افتح Chrome أو Edge.
3. افتح صفحة الإضافات:
   - Chrome: `chrome://extensions/`
   - Edge: `edge://extensions/`
4. فعّل Developer Mode.
5. اختر Load unpacked.
6. اختر مجلد الإضافة بعد فك الضغط.

## الصلاحيات المستخدمة

- `activeTab`, `tabs`: قراءة الرابط الحالي.
- `scripting`: فحص DOM للصفحة الحالية عند طلب المستخدم.
- `cookies`: عدّ Cookies للصفحة الحالية.
- `webRequest`: التقاط Response Security Headers للصفحة الرئيسية.
- `storage`: حفظ مؤقت محلي للنتائج والترويسات.
- `host_permissions`: السماح بالفحص على صفحات HTTP/HTTPS التي يفتحها المستخدم.

## ملاحظات أكاديمية

هذه الإضافة مناسبة للعرض كمشروع دفاعي بعنوان:

**WebShield Security Toolkit: A Local Browser-Based Cybersecurity Awareness and Analysis Extension**

ولا تحتوي على أي وظيفة لسرقة كلمات المرور، استنساخ مواقع، أو إرسال بيانات المستخدمين إلى خادم خارجي.
