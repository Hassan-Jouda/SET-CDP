# SET-CDP AdShield Pro

A powerful Manifest V3 browser extension for ad blocking, tracker blocking, and cosmetic page cleaning.

## Features

- Network-level ad blocking using Declarative Net Request
- Tracker blocking for common analytics and privacy-invasive domains
- Cosmetic ad hiding for common ad containers
- YouTube cosmetic cleaning selectors
- Simple ON/OFF control
- Separate Privacy Protection toggle
- Separate Cosmetic Cleaning toggle
- Local settings only; no backend server

## Installation

1. Extract the ZIP file.
2. Open Chrome or Edge.
3. Go to:

```text
chrome://extensions/
```

4. Enable Developer mode.
5. Click Load unpacked.
6. Select the extracted extension folder.

## Important Note About YouTube

YouTube frequently changes its ad delivery and interface. This extension includes common network and cosmetic blocking techniques, but no extension can honestly guarantee 100% blocking forever, especially under Manifest V3 restrictions.

## Academic Presentation Idea

This can be presented as a privacy and web security extension that demonstrates:

- Browser extension architecture
- Manifest V3
- Declarative Net Request
- Tracker blocking
- DOM cosmetic filtering
- User privacy protection
